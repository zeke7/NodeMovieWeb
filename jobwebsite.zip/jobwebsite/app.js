var express = require('express');
var port = process.env.PORT || 3000;
var path = require('path');
var app = express();
var bodyParser = require('body-parser');

app.set('views', './views/pages');
app.set('view engine', 'pug');
app.use(bodyParser.urlencoded());
app.use(express.static(path.join(__dirname, 'bower_components')));
app.use('/static',express.static(__dirname + '/static'));
app.listen(port);


console.log('imooc started on port '+port);

//index
app.get('/index', function(req, res) {
	res.render('index',{
		title: 'Imooc index',
		movies:[
		{
			title: "movies1",
			_id:1,
			poster:"/static/movie1.jpg"
		},
		{
			title: "movies2",
			_id:2,
			poster:"/static/movie2.jpg"
		},
		{
			title: "movies3",
			_id:3,
			poster:"/static/movie3.jpg"
		}]
	});
});


// admin
app.get('/admin/movie', function(req, res) {
	res.render('admin',{
		title: 'Imooc admin',
		movies:{
			id:1,
			title: "",
			country: "",
			language: ""
		}
	});
});

//detail
app.get('/movie/:id', function(req, res) {
	res.render('detail',{
		title: 'Imooc detail',
		movies:{
			flash:"http://player.youku.com/player.php/sid/XNjA0NDI1ODQ0/v.swf",
			title: "Jin Gang Lang",
			country: "China",
			language: "Chinese"
		}
	});
});

//list
app.get('/admin/list', function(req, res) {
	res.render('list',{
		title: 'Imooc list',
		movies:[{
			id: 1,
			title: "mmmmmmmmmmovies1",
			country:"China",
			language:"Chinese"
		}]
	});
});